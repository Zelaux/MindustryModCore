[![](https://github.com/Anuken/Arc/workflows/Java%20CI/badge.svg)](https://github.com/Anuken/Arc/actions)
