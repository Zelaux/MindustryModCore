package arc.scene.style;

public abstract class Style{

}
