package arc.func;

public interface Func<P, R>{
    R get(P param);
}
