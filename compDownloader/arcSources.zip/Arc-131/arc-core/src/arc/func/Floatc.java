package arc.func;

public interface Floatc{
    void get(float f);
}
