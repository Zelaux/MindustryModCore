package arc.func;

public interface Floatf<T>{
    float get(T t);
}
