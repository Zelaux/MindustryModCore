package arc.func;

public interface Intf<T>{
    int get(T t);
}
