package arc.net;

public enum DcReason{
    timeout, closed, error
}
