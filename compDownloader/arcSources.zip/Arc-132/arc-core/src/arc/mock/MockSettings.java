package arc.mock;

import arc.*;

public class MockSettings extends Settings{

    @Override
    public void load(){

    }

    @Override
    public void forceSave(){

    }

}
