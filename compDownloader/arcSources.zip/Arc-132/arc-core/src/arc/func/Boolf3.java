package arc.func;

public interface Boolf3<P1, P2, P3>{
    boolean get(P1 a, P2 b, P3 c);
}
