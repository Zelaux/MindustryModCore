package arc.func;

public interface Longf<T>{
    long get(T t);
}
