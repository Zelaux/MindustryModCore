package arc.func;

public interface Intc{
    void get(int i);
}
