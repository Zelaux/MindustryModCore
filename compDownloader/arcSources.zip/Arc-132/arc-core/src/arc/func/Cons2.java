package arc.func;

public interface Cons2<T, N>{
    void get(T t, N n);
}
