package arc.func;

public interface Intp{
    int get();
}
