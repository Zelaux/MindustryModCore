package arc.func;

public interface IntIntf{
    int get(int value);
}
