package arc.func;

public interface Intc4{
    void get(int x, int y, int x2, int y2);
}
