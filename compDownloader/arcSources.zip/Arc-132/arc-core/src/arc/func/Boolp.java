package arc.func;

public interface Boolp{
    boolean get();
}
