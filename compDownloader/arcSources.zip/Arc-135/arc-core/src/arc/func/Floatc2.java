package arc.func;

public interface Floatc2{
    void get(float x, float y);
}
