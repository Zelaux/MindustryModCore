package arc.func;

public interface FloatFloatf{
    float get(float f);
}
