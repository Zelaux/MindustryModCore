package mindustry.io.versions;

import mindustry.io.*;

public class Save5 extends SaveVersion{

    public Save5(){
        super(5);
    }
}
