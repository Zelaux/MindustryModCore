package mindustry.logic;

public enum LLocate{
    ore,
    building,
    spawn,
    damaged;

    public static final LLocate[] all = values();
}
