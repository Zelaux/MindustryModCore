package mindustry.mod;

/** Defines a special type of mod that is always hidden. */
public abstract class Plugin extends Mod{

}
