package mindustry.entities.comp;

import mindustry.annotations.Annotations.*;
import mindustry.gen.*;

@Component
abstract class ShielderComp implements Damagec, Teamc, Posc{

    void absorb(){

    }
}
